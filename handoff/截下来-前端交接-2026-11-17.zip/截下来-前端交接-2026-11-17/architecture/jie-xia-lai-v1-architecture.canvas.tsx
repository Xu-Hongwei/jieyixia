import {
  Callout,
  Code,
  CollapsibleSection,
  Divider,
  Grid,
  H1,
  H2,
  Pill,
  Row,
  Select,
  SendToChatButton,
  Stack,
  Stat,
  Table,
  Tag,
  Text,
  Timeline,
  useCanvasState,
  useHostTheme,
} from "qoder/canvas";
import type { TableRowTone } from "qoder/canvas";

/* ------------------------------------------------------------------ *
 * 「截下来」V1 · 架构与领域模型评审基线
 * 依据：截下来_V1_功能需求草案_v0.2_含多任务规划.md（讨论稿）
 * 已确认技术栈：Vue 3 + JavaScript + Tailwind CSS + Vite / Python + FastAPI
 * ------------------------------------------------------------------ */

type PlanTask = {
  id: string;
  title: string;
  due: number | null;
  remaining: number;
  splittable: boolean;
  from: string;
};

type Slot = { id: string; minutes: number };

type TaskOutcome = {
  id: string;
  title: string;
  due: number | null;
  remaining: number;
  scheduled: number;
  gap: number;
  outside: boolean;
  splittable: boolean;
};

const TASKS: PlanTask[] = [
  { id: "algo", title: "算法作业", due: 2, remaining: 180, splittable: true, from: "F03 便签确认" },
  { id: "prob", title: "概率论复习", due: 6, remaining: 150, splittable: true, from: "F13 批量录入" },
  { id: "lab", title: "实验数据整理", due: 6, remaining: 90, splittable: false, from: "F13 批量录入" },
  { id: "ml", title: "机器学习课程报告", due: 9, remaining: 240, splittable: true, from: "F03 便签确认" },
  { id: "read", title: "论文精读（无截止）", due: null, remaining: 60, splittable: true, from: "F05 参考类便签" },
];

const BASE_DATE = new Date(2026, 10, 17);
const WEEKDAYS = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"];

function dayLabel(offset: number): string {
  const d = new Date(BASE_DATE.getFullYear(), BASE_DATE.getMonth(), BASE_DATE.getDate() + offset);
  const wd = WEEKDAYS[d.getDay()] ?? "";
  return `${d.getMonth() + 1}/${d.getDate()} ${wd}`;
}

function minutesText(min: number): string {
  if (min < 60) return `${min} 分`;
  const h = Math.floor(min / 60);
  const m = min % 60;
  return m === 0 ? `${h} 小时` : `${h} 小时 ${m} 分`;
}

/**
 * F13.3 的确定性排程规则：EDD 贪心 + 允许拆分 + 每日缓冲预留。
 * 返回类型强制携带 gap，使「假装已排完」无法被表达。
 */
function buildPlan(tasks: PlanTask[], horizon: number, budget: number, bufferPct: number) {
  const caps: number[] = [];
  for (let i = 0; i < horizon; i += 1) {
    caps.push(Math.max(0, Math.round(budget * (1 - bufferPct / 100))));
  }
  const days: Slot[][] = caps.map(() => [] as Slot[]);
  const usedOf = (index: number) => (days[index] ?? []).reduce((sum, s) => sum + s.minutes, 0);

  const ordered = tasks.slice().sort((a, b) => {
    const da = a.due === null ? 9999 : a.due;
    const db = b.due === null ? 9999 : b.due;
    if (da !== db) return da - db;
    return b.remaining - a.remaining;
  });

  const outcomes: TaskOutcome[] = [];
  for (const task of ordered) {
    const outside = task.due !== null && task.due > horizon - 1;
    const last = task.due === null ? horizon - 1 : Math.min(task.due, horizon - 1);
    let need = task.remaining;

    if (!task.splittable) {
      for (let d = 0; d <= last; d += 1) {
        const free = (caps[d] ?? 0) - usedOf(d);
        const bucket = days[d];
        if (bucket && free >= need) {
          bucket.push({ id: task.id, minutes: need });
          need = 0;
          break;
        }
      }
    } else {
      for (let d = 0; d <= last && need > 0; d += 1) {
        const free = (caps[d] ?? 0) - usedOf(d);
        const bucket = days[d];
        if (!bucket || free <= 0) continue;
        const take = Math.min(free, need);
        bucket.push({ id: task.id, minutes: take });
        need -= take;
      }
    }

    outcomes.push({
      id: task.id,
      title: task.title,
      due: task.due,
      remaining: task.remaining,
      scheduled: task.remaining - need,
      gap: need,
      outside,
      splittable: task.splittable,
    });
  }

  const gapTotal = outcomes.reduce((sum, o) => sum + o.gap, 0);
  const usedTotal = outcomes.reduce((sum, o) => sum + o.scheduled, 0);
  const capacityTotal = caps.reduce((sum, c) => sum + c, 0);
  return { caps, days, outcomes, gapTotal, usedTotal, capacityTotal };
}

/* ------------------------------ 领域模型图 ------------------------------ */

function DomainDiagram() {
  const { tokens } = useHostTheme();
  const boxW = 210;
  const boxH = 60;
  const laneX = [8, 298, 588];
  const boxX = [18, 308, 598];
  const rowY = [70, 186, 302, 418];

  const entities: Array<{
    x: number;
    y: number;
    name: string;
    en: string;
    fields: string;
    tone?: "core" | "weak" | "p1";
  }> = [
    { x: boxX[0] ?? 18, y: rowY[0] ?? 70, name: "Source 原始资料", en: "不可覆盖", fields: "image_blob · captured_at · origin", tone: "core" },
    { x: boxX[0] ?? 18, y: rowY[1] ?? 186, name: "Note 行动便签", en: "4 态状态机", fields: "status · Field[] · source_id", tone: "core" },
    { x: boxX[0] ?? 18, y: rowY[2] ?? 302, name: "Matter 事项", en: "V1 一个主事项", fields: "title · note_ids[] · 资料角色", tone: "core" },
    { x: boxX[1] ?? 308, y: rowY[1] ?? 186, name: "Task 任务", en: "4 态", fields: "deadline{value, from_note_id}", tone: "core" },
    { x: boxX[1] ?? 308, y: rowY[2] ?? 302, name: "Action 下一步", en: "可改可跳过", fields: "text · minutes · basis", tone: "core" },
    { x: boxX[1] ?? 308, y: rowY[3] ?? 418, name: "FocusSession 专注", en: "同时仅一个", fields: "started_at + acc_ms · plan_item_id", tone: "core" },
    { x: boxX[2] ?? 598, y: rowY[0] ?? 70, name: "PlanDraft 草案", en: "未确认即丢弃", fields: "horizon · items[] · 不落正式库", tone: "weak" },
    { x: boxX[2] ?? 598, y: rowY[1] ?? 186, name: "PlanItem 计划条目", en: "永不回写 Task", fields: "task_id · date · planned_min", tone: "core" },
    { x: boxX[2] ?? 598, y: rowY[2] ?? 302, name: "ChangeProposal", en: "F06 · P1", fields: "新 Note × 已有 Task → 候选", tone: "p1" },
  ];

  const laneTitles = ["资料层 · F01–F05", "行动层 · F07–F10", "规划层 F13 ＋ 增强"];

  const vEdge = (x: number, y1: number, y2: number, label: string) => (
    <g key={`v-${x}-${y1}`}>
      <path d={`M ${x} ${y1} L ${x} ${y2}`} fill="none" stroke={tokens.stroke.secondary} strokeWidth={1.4} markerEnd="url(#je-arrow)" />
      <text x={x + 9} y={(y1 + y2) / 2 + 3} fill={tokens.text.tertiary} fontSize={10.5}>
        {label}
      </text>
    </g>
  );

  const hEdge = (x1: number, x2: number, y: number, label: string) => (
    <g key={`h-${x1}-${y}`}>
      <path d={`M ${x1} ${y} L ${x2} ${y}`} fill="none" stroke={tokens.stroke.secondary} strokeWidth={1.4} markerEnd="url(#je-arrow)" />
      <text x={(x1 + x2) / 2} y={y - 8} fill={tokens.text.tertiary} fontSize={10.5} textAnchor="middle">
        {label}
      </text>
    </g>
  );

  return (
    <svg viewBox="0 0 830 552" width="100%" role="img" aria-label="截下来 V1 领域模型实体关系图">
      <defs>
        <marker id="je-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
          <path d="M 0 0 L 10 5 L 0 10 z" fill={tokens.stroke.secondary} />
        </marker>
      </defs>

      {laneX.map((lx, i) => (
        <g key={`lane-${i}`}>
          <rect x={lx} y={52} width={230} height={442} rx={tokens.radius.md} fill={tokens.fill.quaternary} />
          <text x={lx + 115} y={36} fill={tokens.text.secondary} fontSize={12} fontWeight={600} textAnchor="middle">
            {laneTitles[i]}
          </text>
        </g>
      ))}

      {vEdge(123, 130, 186, "1 : 1")}
      {vEdge(123, 246, 302, "N : 1 可空")}
      {vEdge(413, 246, 302, "1 : N")}
      {vEdge(413, 362, 418, "1 : N")}
      {vEdge(703, 130, 186, "确认才落地")}
      {hEdge(228, 308, 216, "转任务预填")}
      {hEdge(518, 598, 216, "1 : N 引用")}

      {entities.map((e) => {
        const strokeColor =
          e.tone === "p1" ? tokens.stroke.tertiary : e.tone === "core" ? tokens.accent.control : tokens.stroke.secondary;
        return (
          <g key={e.name}>
            <rect
              x={e.x}
              y={e.y}
              width={boxW}
              height={boxH}
              rx={tokens.radius.sm}
              fill={tokens.bg.elevated}
              stroke={strokeColor}
              strokeWidth={1.3}
              strokeDasharray={e.tone === "p1" ? "4 3" : undefined}
            />
            <text x={e.x + 12} y={e.y + 23} fill={tokens.text.primary} fontSize={13} fontWeight={650}>
              {e.name}
            </text>
            <text x={e.x + boxW - 12} y={e.y + 23} fill={tokens.text.tertiary} fontSize={9.5} textAnchor="end">
              {e.en}
            </text>
            <text x={e.x + 12} y={e.y + 44} fill={tokens.text.tertiary} fontSize={9.5}>
              {e.fields}
            </text>
          </g>
        );
      })}

      <text x={10} y={522} fill={tokens.text.quaternary} fontSize={10}>
        三条写路径：Source→Note（AI 只写 candidate）· Note→Task（仅搬运已 confirmed 的字段）· PlanDraft→PlanItem（只有「确认」这一个动作）。
      </text>
      <text x={10} y={540} fill={tokens.text.quaternary} fontSize={10}>
        Task 与 PlanItem 之间不存在反向写路径（规则 11/12）：计划不改截止时间，专注记实际用时，计划条目记计划用时。
      </text>
    </svg>
  );
}

/* ------------------------------ F13 排程模拟 ------------------------------ */

function PlannerLab() {
  const { tokens } = useHostTheme();
  const [horizonRaw, setHorizon] = useCanvasState<string>("je.horizon", "7");
  const [budgetRaw, setBudget] = useCanvasState<string>("je.budget", "90");
  const [bufferRaw, setBuffer] = useCanvasState<string>("je.buffer", "15");

  const horizon = Number(horizonRaw);
  const budget = Number(budgetRaw);
  const bufferPct = Number(bufferRaw);
  const result = buildPlan(TASKS, horizon, budget, bufferPct);

  const palette = [
    tokens.chart.blue,
    tokens.chart.green,
    tokens.chart.goldenYellow,
    tokens.chart.brightOrange,
    tokens.chart.purple,
    tokens.chart.teal,
  ];
  const colorOf = (id: string) => {
    const idx = TASKS.findIndex((t) => t.id === id);
    return palette[idx % palette.length] ?? tokens.accent.control;
  };

  const totalNeed = TASKS.reduce((s, t) => s + t.remaining, 0);

  return (
    <Stack gap={16}>
      <Row gap={12} align="end" wrap>
        <Stack gap={4}>
          <Text size="small" tone="secondary">
            规划范围 F13.2
          </Text>
          <Select
            value={horizonRaw}
            onChange={setHorizon}
            options={[
              { value: "3", label: "3 天" },
              { value: "7", label: "7 天（默认）" },
              { value: "14", label: "14 天" },
            ]}
            style={{ width: 132 }}
          />
        </Stack>
        <Stack gap={4}>
          <Text size="small" tone="secondary">
            每日可用时长
          </Text>
          <Select
            value={budgetRaw}
            onChange={setBudget}
            options={[
              { value: "45", label: "45 分钟" },
              { value: "90", label: "90 分钟" },
              { value: "120", label: "120 分钟" },
              { value: "180", label: "180 分钟" },
            ]}
            style={{ width: 132 }}
          />
        </Stack>
        <Stack gap={4}>
          <Text size="small" tone="secondary">
            每日缓冲预留
          </Text>
          <Select
            value={bufferRaw}
            onChange={setBuffer}
            options={[
              { value: "0", label: "关闭" },
              { value: "15", label: "15%（默认）" },
              { value: "20", label: "20%" },
            ]}
            style={{ width: 132 }}
          />
        </Stack>
        <Text size="small" tone="tertiary">
          示例数据 5 项任务，合计需 {minutesText(totalNeed)}；可分配容量 {minutesText(result.capacityTotal)}
        </Text>
      </Row>

      <Stack gap={6}>
        {result.days.map((slots, i) => {
          const bucket = slots ?? [];
          const used = bucket.reduce((s, x) => s + x.minutes, 0);
          const cap = result.caps[i] ?? 0;
          const bufferMin = budget - cap;
          const free = Math.max(0, cap - used);
          const pct = (m: number) => `${(m / Math.max(1, budget)) * 100}%`;
          const dueHere = TASKS.filter((t) => t.due === i);
          return (
            <Row key={`d-${i}`} gap={10} align="center">
              <Text size="small" style={{ width: 74, flexShrink: 0 }}>
                {dayLabel(i)}
              </Text>
              <div
                style={{
                  flex: 1,
                  height: 22,
                  display: "flex",
                  borderRadius: tokens.radius.xs,
                  overflow: "hidden",
                  background: tokens.fill.quaternary,
                  border: `1px solid ${tokens.stroke.quaternary}`,
                }}
              >
                {bucket.map((s) => (
                  <div
                    key={`${i}-${s.id}`}
                    title={`${s.id} · ${minutesText(s.minutes)}`}
                    style={{ width: pct(s.minutes), background: colorOf(s.id) }}
                  />
                ))}
                <div style={{ width: pct(free) }} />
                {bufferMin > 0 ? (
                  <div
                    title={`缓冲预留 ${minutesText(bufferMin)}`}
                    style={{
                      width: pct(bufferMin),
                      marginLeft: "auto",
                      background: tokens.fill.disable,
                      borderLeft: `1px dashed ${tokens.stroke.tertiary}`,
                    }}
                  />
                ) : null}
              </div>
              <Text size="small" tone="secondary" style={{ width: 92, flexShrink: 0, textAlign: "right" }}>
                {used} / {cap} 分
              </Text>
              <div style={{ width: 84, flexShrink: 0 }}>
                {dueHere.length > 0 ? (
                  <Pill tone="warning" size="sm">
                    {dueHere.map((t) => t.title.slice(0, 2)).join("·")} 截止
                  </Pill>
                ) : null}
              </div>
            </Row>
          );
        })}
        <Row gap={12} wrap>
          {TASKS.map((t) => (
            <Row key={`lg-${t.id}`} gap={5} align="center">
              <div style={{ width: 10, height: 10, borderRadius: 2, background: colorOf(t.id) }} />
              <Text size="small" tone="secondary">
                {t.title}
                {t.splittable ? "" : "（不可拆分）"}
              </Text>
            </Row>
          ))}
          <Row gap={5} align="center">
            <div style={{ width: 10, height: 10, borderRadius: 2, background: tokens.fill.disable }} />
            <Text size="small" tone="secondary">
              缓冲预留
            </Text>
          </Row>
        </Row>
      </Stack>

      {result.gapTotal > 0 ? (
        <Callout tone="warning" title={`排不下：仍有 ${minutesText(result.gapTotal)} 未分配`}>
          <Stack gap={4}>
            {result.outcomes
              .filter((o) => o.gap > 0)
              .map((o) => (
                <Text key={`g-${o.id}`} size="small">
                  {o.title}：已排 {o.scheduled} 分 / 需 {o.remaining} 分 → 缺 {minutesText(o.gap)}
                  {o.due !== null ? `（截止 ${dayLabel(o.due)}）` : "（无截止，可留未排程）"}
                  {!o.splittable ? " · 不可拆分，整块放不下即全未排" : ""}
                </Text>
              ))}
            <Text size="small" tone="tertiary">
              对应 PRD F13.3「不得假装已安排完成」与决策项 11：允许任务保持未排程，不虚构工时。
            </Text>
          </Stack>
        </Callout>
      ) : (
        <Callout tone="success" title="全部排入，无缺口">
          <Text size="small">
            共使用 {minutesText(result.usedTotal)}，剩余空余 {minutesText(Math.max(0, result.capacityTotal - result.usedTotal))}。
            计划草案仍需用户点「确认」才写入 PlanItem；取消不影响既有计划与任务。
          </Text>
        </Callout>
      )}

      <Table
        density="compact"
        headers={["任务", "来源", "截止", "需时", "已排入", "状态"]}
        rows={result.outcomes.map((o) => [
          o.title,
          TASKS.find((t) => t.id === o.id)?.from ?? "",
          o.due === null ? "无截止" : dayLabel(o.due),
          `${o.remaining} 分`,
          `${o.scheduled} 分`,
          o.gap > 0 ? "部分未排" : o.outside ? "已排入（截止在窗口外）" : "已排入",
        ])}
        rowTone={result.outcomes.map((o): TableRowTone => (o.gap > 0 ? "warning" : "default"))}
      />
    </Stack>
  );
}

/* ------------------------------ 数据流 ------------------------------ */

function FlowStrip() {
  const { tokens } = useHostTheme();
  const steps = [
    { t: "① 粘贴 / 拖入", d: "Ctrl+V、文件、纯文字（F01）" },
    { t: "② 生成 source_id", d: "客户端生成，重试不产生重复资料" },
    { t: "③ 立即写 IndexedDB", d: "原图先落盘，AI 失败也不丢（F11）" },
    { t: "④ POST /analyze", d: "唯一一次跨网络调用" },
    { t: "⑤ 草稿写回 Note", d: "status = candidate" },
    { t: "⑥ 用户逐字段确认", d: "confirmed ｜ unresolved" },
    { t: "⑦ Task → PlanItem", d: "F07 / F13，AI 不写 deadline" },
    { t: "⑧ FocusSession", d: "F10，实际用时回写自己" },
  ];
  return (
    <Stack gap={12}>
      <Row gap={6} align="stretch" wrap>
        {steps.map((s, i) => (
          <div
            key={s.t}
            style={{
              flex: "1 1 148px",
              minWidth: 148,
              padding: 10,
              borderRadius: tokens.radius.sm,
              border: `1px solid ${i === 3 ? tokens.accent.control : tokens.stroke.quaternary}`,
              background: i === 3 ? tokens.status.infoBg : tokens.bg.panel,
            }}
          >
            <Text size="small" weight="semibold">
              {s.t}
            </Text>
            <Text size="small" tone="tertiary">
              {s.d}
            </Text>
          </div>
        ))}
      </Row>
      <Grid columns={2} gap={12} minColumnWidth={320}>
        <Callout tone="info" title="前端 = 唯一事实源">
          <Text size="small">
            Pinia store 只管视图状态；持久层是 <Code>storage/persistence</Code> 一个模块，其它代码不直接摸 IndexedDB。断网时 ①②③⑤⑥⑦⑧ 全部照常，仅 ④ 不可用并给出降级提示。
          </Text>
        </Callout>
        <Callout tone="neutral" title="后端 = 无状态智能代理">
          <Text size="small">
            FastAPI 不建库、不建表、不落用户原图（PRD 第 365 行），不进普通运行日志。模型密钥只在后端环境变量，前端永不接触。图片只在这次请求里以 base64 出现。
          </Text>
        </Callout>
      </Grid>
    </Stack>
  );
}

/* ------------------------------ 主画布 ------------------------------ */

export default function JieXiaLaiArchitecture() {
  const { tokens } = useHostTheme();
  const [showRules, setShowRules] = useCanvasState<string>("je.rules", "core");

  const preStyle = {
    padding: 12,
    borderRadius: tokens.radius.sm,
    background: tokens.bg.panel,
    border: `1px solid ${tokens.stroke.quaternary}`,
    color: tokens.text.secondary,
    fontSize: "12px",
    lineHeight: "1.65",
    overflowX: "auto",
    whiteSpace: "pre",
    fontFamily: "var(--canvas-font-mono, ui-monospace, monospace)",
    margin: 0,
  } as const;

  return (
    <Stack gap={24}>
      <Stack gap={8}>
        <H1>「截下来」V1 · 架构与领域模型评审基线</H1>
        <Text tone="secondary">
          截图驱动的 AI 行动便签 Web 应用 · 本地优先 + 无状态智能代理 · 依据 PRD v0.2 讨论稿（第 4 章 F01–F13、第 6 章 13 条业务规则）
        </Text>
        <Row gap={6} wrap>
          <Tag tone="primary">Vue 3</Tag>
          <Tag tone="primary">JavaScript</Tag>
          <Tag tone="primary">Tailwind CSS</Tag>
          <Tag tone="primary">Vite</Tag>
          <Tag tone="info">Python + FastAPI</Tag>
          <Tag tone="info">IndexedDB</Tag>
          <Tag tone="neutral">无账号 / 无同步</Tag>
        </Row>
      </Stack>

      <Grid columns={4} gap={12} minColumnWidth={150}>
        <Stat label="核心开发周期" value="15" unit="天" description="3 人并行，P0 优先" />
        <Stat label="P0 功能项" value="11" unit="项" description="F06 与全部智能增强归 P1" tone="info" />
        <Stat label="后端接口" value="5" unit="个" description="4 个智能接口 + /healthz" tone="info" />
        <Stat label="领域实体" value="8 + 1" unit="个" description="8 个核心概念 + ChangeProposal(P1)" />
      </Grid>

      <Divider />

      <Stack gap={12}>
        <H2>一、范围判断：先锁死 P0 边界</H2>
        <Text tone="secondary">
          PRD 第 112 行已给出 P1 优先顺序，但 15 天 / 3 人对 13 个 F 项仍然偏满。建议在第 1 天就把下面几项明确写进排期为「不做」，而不是等到第 7 天再砍。
        </Text>
        <Grid columns={3} gap={12} minColumnWidth={240}>
          <Callout tone="success" title="P0 必做（8 项）">
            <Stack gap={3}>
              <Text size="small">F01 收集 · F02 识别 · F03 便签 · F04 收集箱</Text>
              <Text size="small">F05 手动归组 · F07 任务 · F08 今天 · F10 专注</Text>
              <Text size="small">F11 持久化 + 简易导出 · F12 演示模式</Text>
              <Text size="small">F13 结构化批量录入 + 规则排程</Text>
            </Stack>
          </Callout>
          <Callout tone="warning" title="本轮建议直接推后">
            <Stack gap={3}>
              <Text size="small">F06 截止时间变更检测（依赖 /match，风险最高）</Text>
              <Text size="small">F05 AI 建议归组 · F09 AI 行动建议</Text>
              <Text size="small">F13 自然语言解析 / 智能估时 / 逾期重排</Text>
              <Text size="small">F03 原图坐标级高亮（PRD 第 192 行已声明不要求）</Text>
            </Stack>
          </Callout>
          <Callout tone="danger" title="提级为 P0 的非常规项">
            <Stack gap={3}>
              <Text size="small">简易备份导出（PRD 决策项 7）——半天工作量，但比赛现场数据被浏览器清掉就是零分</Text>
              <Text size="small">navigator.storage.persist() 申请与失败提示</Text>
              <Text size="small">/healthz 可用性探测——驱动全站「AI 暂不可用」降级态</Text>
            </Stack>
          </Callout>
        </Grid>
      </Stack>

      <Divider />

      <Stack gap={12}>
        <H2>二、领域模型：8 个实体，3 条写路径</H2>
        <Text tone="secondary">
          PRD 第 55-66 行的概念表已经给出实体清单。真正需要评审确认的是「谁能写谁」——下面三列切分了资料层 / 行动层 / 规划层，层间只有单向引用。
        </Text>
        <DomainDiagram />
      </Stack>

      <CollapsibleSection title="实体关系要点与例外" defaultOpen={false}>
        <Table
          density="compact"
          headers={["关系", "基数", "写规则", "PRD 依据"]}
          rows={[
            ["Source → Note", "1 : 1", "一张便签对应一个输入；原图永不因编辑便签而变", "规则 1、5；F03 第 189 行"],
            ["Note → Matter", "N : 1（可空）", "V1 一张便签最多一个主要事项；移出即回收集箱", "F05 第 224 行；决策项 2"],
            ["Note ↔ Task", "N : N", "Task 存 note_ids[]；创建时预填，用户可改", "F07 第 262、268 行"],
            ["Task → Action", "1 : N", "一个任务允许多个已完成行动", "决策项 3（建议：允许）"],
            ["Action → FocusSession", "1 : N", "同时活动会话最多 1 个，boot 时收敛孤儿会话", "规则 8；F10 第 340 行"],
            ["Task → PlanItem", "1 : N", "只引用 task_id，禁止回写 deadline / status", "规则 11、12；F13.5"],
            ["PlanDraft → PlanItem", "1 : N", "仅「确认」这一个动作产生 PlanItem", "F13.4 第 448 行"],
            ["Note × Task → ChangeProposal", "候选", "新便签与旧通知比较，确认后才有写路径到 Task", "F06（P1）"],
            ["FocusSession → Task", "只读", "实际用时回写自身，不自动完成任务", "决策项 13（建议：不自动完成）"],
          ]}
          rowTone="default"
        />
      </CollapsibleSection>

      <Divider />

      <Stack gap={12}>
        <H2>三、核心值对象 Field：一个结构满足 4 条业务规则</H2>
        <Text tone="secondary">
          规则 2「事实与建议分离」、规则 4「来源可追溯」、规则 7「时间语义明确」、F03「字段确认状态与便签状态不同」——这四条不要用四套状态机实现，统一收在字段级。
        </Text>
        <Grid columns={2} gap={12} minColumnWidth={320}>
          <pre style={preStyle}>
{`/** 便签的每个重要字段都是 Field，不是裸值 */
typedef Field = {
  key:        'deadline' | 'materials' | 'title' | ...
  value:      any | null        // 用户确认后的值
  raw:        string            // 原文片段，永不为空
  origin:     'model' | 'user'  // 谁写的
  status:     'candidate'       // AI 产出，未审阅
            | 'confirmed'       // 用户已确认
            | 'unresolved'      // 无法可靠确定（相对时间等）
            | 'missing'         // 原文确实没提
  derived:    boolean           // 是否由推算得到（如相对日期换算）
  quote:      { text, source_id }
}

// 便签整体状态是另一维，不能被字段状态替代
Note.status = 'pending' | 'draft' | 'reviewed' | 'failed'`}
          </pre>
          <Stack gap={10}>
            <Callout tone="warning" title="相对时间的具体填法（PRD 第 157 行留白）">
              <Text size="small">
                把 <Code>captured_at</Code>（保存时间）作为参照日期传给模型。可换算时写 <Code>value</Code> + <Code>derived: true</Code> + <Code>status: 'unresolved'</Code>；
                UI 显示「原文『下周五』 · 系统推算 11/20 · 待确认」。不换算就整条链路卡在待确认，换算但不标记就会伪造事实——这个折中是决策项 1 的实际答案。
              </Text>
            </Callout>
            <Callout tone="info" title="截止时间出处（决策项 5）">
              <Text size="small">
                <Code>Task.deadline = {'{ value, confirmed_from_note_id, confirmed_at }'}</Code>。
                F06 确认后保留变更前后值即来自这条；「AI 不直接修改」由类型层面禁止：<Code>origin</Code> 为 model 的字段不可直接映射到 Task。
              </Text>
            </Callout>
            <Row gap={8} align="center">
              <Text size="small" tone="secondary">
                字段确认颗粒度：
              </Text>
              <Tag tone={showRules === "core" ? "primary" : "neutral"} onClick={() => setShowRules("core")}>
                仅关键字段
              </Tag>
              <Tag tone={showRules === "all" ? "primary" : "neutral"} onClick={() => setShowRules("all")}>
                全部字段
              </Tag>
            </Row>
            <Text size="small" tone="tertiary">
              {showRules === "core"
                ? "建议方案：deadline / materials / submit_to 三类必须独立确认；其余字段随整张「已审阅」标记一起确认。UI 成本最低，且满足 F03 验收第 194 行。"
                : "全字段单独确认会把便签详情页变成一张表单，F03「一眼读懂要点」的目标会被削弱。若采用，建议只对通知类启用。"}
            </Text>
          </Stack>
        </Grid>
      </Stack>

      <Divider />

      <Stack gap={12}>
        <H2>四、前后端边界：黄金路径只有 1 次网络调用</H2>
        <Text tone="secondary">对应 PRD 第 3 章黄金演示路径（步骤 1–9）与 F01「原始内容应先保存」规则。</Text>
        <FlowStrip />
      </Stack>

      <Stack gap={12}>
        <H3>接口契约 v0.1（第 1 天冻结，之后只增不改）</H3>
        <Text tone="secondary">
          PRD 第 592 行建议「功能确认后再定契约」。15 天 / 3 人的节奏下我建议反过来：第 1 天先冻结 v0.1，前后端各拿同一份 fixture 并行，第 10 天联调不会撞墙。
        </Text>
        <Table
          density="compact"
          headers={["接口", "请求要点", "响应要点", "失败语义（必须实现）", "阶段"]}
          rows={[
            [
              "POST /analyze",
              "source_id, image_base64｜text, captured_at, content_hint",
              "content_type + fields: Field[] + warnings[]",
              "模型输出不合 schema → 422 + 原因；前端落 status=failed，原图保留，可重试（幂等键 = source_id）",
              "P0",
            ],
            [
              "GET /healthz",
              "—",
              "{ model_ready: bool }",
              "不可用 → 前端隐藏「AI 整理」入口但保留「仅保存」；F09/F13 手动路径不受影响",
              "P0",
            ],
            [
              "POST /match",
              "note 摘要 + 现有 matters[] / tasks[]",
              "建议 matter_id、置信度、理由",
              "低置信度返回空数组，不强行归组（F05 第 231 行）",
              "P1",
            ],
            [
              "POST /suggest-action",
              "已确认 Task 字段 + 关联便签摘要 + 可用时长",
              "text, minutes, basis: 'requirement'｜'suggestion'",
              "basis 缺失即视为契约违规；前端必须显示「AI 建议」标签（F09 第 314 行）",
              "P1",
            ],
            [
              "POST /parse-tasks",
              "一段自由文本",
              "tasks[]{ title, due_raw, derived_due, effort_raw, unresolved[] }",
              "任何不可靠项标 unresolved；绝不返回可直接入库的对象（F13.1 第 403 行）",
              "P1",
            ],
          ]}
          rowTone={["default", "default", "muted", "muted", "muted"]}
        />
        <Grid columns={2} gap={12} minColumnWidth={320}>
          <Callout tone="info" title="契约的单一来源（前端是 JS，不走 TS 类型生成）">
            <Text size="small">
              Pydantic 模型 → <Code>contract/schema.json</Code>（FastAPI <Code>/openapi.json</Code> 导出）→ 生成 <Code>contract/typedefs.d.ts</Code> 纯 JSDoc 声明。
              构建产物不含类型代码，只在 <Code>jsconfig.json</Code> 开 <Code>checkJs</Code> 让编辑器和 CI 校验。后端 <Code>tests/fixtures/</Code> 与前端 <Code>src/mock/</Code> 用同一批 JSON，漂移当场暴露。
            </Text>
          </Callout>
          <Callout tone="neutral" title="开发期调用方式">
            <Text size="small">
              Vite <Code>server.proxy</Code> 把 <Code>/api</Code> 转发到 127.0.0.1:8000，避免 CORS；后端只 allow-local 源。演示环境同源部署时同一份配置直接可用。
              截图 base64 单张可达数 MB，代理要放开请求体上限（FastAPI <Code>LimitConcurrency</Code> / 反向代理 <Code>client_max_body_size</Code>），默认值会在联调时表现为莫名其妙的 413。
            </Text>
          </Callout>
        </Grid>
      </Stack>

      <Divider />

      <Stack gap={12}>
        <H2>五、F13 排程：纯函数 + 可现场调参</H2>
        <Text tone="secondary">
          把 <Code>plan()</Code> 写成不依赖 Vue、不依赖网络的纯模块（<Code>domains/plan/planner.js</Code>），PRD 第 466-479 行的 10 个边界场景直接当测试用例。
          下面就是这份规则的实现，评审时可以现场调参数验证「工时不足必须显式暴露」这条是否成立。
        </Text>
        <PlannerLab />
      </Stack>

      <CollapsibleSection title="planner 的返回契约与前端目录建议" defaultOpen={false}>
        <Grid columns={2} gap={12} minColumnWidth={320}>
          <pre style={preStyle}>
{`plan(tasks, { horizon, budgets, bufferPct })
  -> {
       days: [{ date, slots: [{ task_id,
                  minutes, action_text }] }],
       unscheduled: [{ task_id, gap_minutes,
                       reason: 'no_capacity'
                             | 'no_due_date'
                             | 'not_splittable' }],
       gap_total:      number,   // 必填，不可省略
       conflicts:      [{ task_id, kind }],
       diff_from_confirmed: [...]  // 重算前先给差异
     }

// 返回类型里没有「成功」这一支，
// 「看起来排完了」在类型层面就写不出来。`}
          </pre>
          <pre style={preStyle}>
{`src/
  app/            路由 · 布局 · 三区入口
  domains/
    collect/      F01  粘贴、拖入、仅保存
    notes/        F02 F03  字段确认、原图查看
    inbox/        F04  搜索、筛选、安全删除
    matters/      F05 (F06 P1)
    tasks/        F07 F08 F09
    focus/        F10  计时、草稿、恢复
    plan/         F13  planner.js + planner.test.js
  store/          Pinia：workspace note task plan focus
  persistence/    idb.js · persist-request.js · backup.js
  contract/       schema.json · typedefs.d.ts（JSDoc）
  mock/           与后端 tests/fixtures 同一批 JSON
  demo/           F12  独立 workspace_id，默认不落盘

// 所有 key 前缀 = \${workspace_id}:
//   演示空间隔离（决策项 8）几乎白送`}
          </pre>
        </Grid>
      </CollapsibleSection>

      <Divider />

      <Stack gap={12}>
        <H2>六、风险与对策</H2>
        <Table
          density="compact"
          headers={["风险", "为什么 PRD 没盖住", "对策", "等级"]}
          rows={[
            [
              "IndexedDB 被浏览器静默驱逐",
              "F11 只写了「存储不足要告知」，但比赛现场真正的故障是清理站点数据 / 长期未访问被回收，不是写满",
              "启动即请求 storage.persist() 并检测 result；导出备份提级 P0；收集箱顶部常驻「已本地存储 · 建议导出」",
              "critical",
            ],
            [
              "专注计时在后台标签页被节流",
              "F10 只要求「计时开始/暂停/继续」，没规定计时来源",
              "只存 started_at + accumulated_ms（墙上时钟），禁止 setInterval 累加；tick 只用于重渲染",
              "high",
            ],
            [
              "刷新瞬间丢草稿 / 孤儿会话",
              "F10 第 342 行要求「明确处理关闭页面、刷新」，但未给机制",
              "debounce 写盘 + pagehide/visibilitychange 强制 flush；boot 时把无主会话收敛为「未完成的专注」",
              "high",
            ],
            [
              "上传成功但分析超时 → 重复资料",
              "F01 验收要求「解析失败支持重试」，重试语义未定义",
              "客户端生成 source_id 作幂等键；重试只带 id 不重新入库",
              "medium",
            ],
            [
              "范围过满导致 P0 跑不通",
              "13 个 F 项 / 3 人 / 15 天；决策项 9 已有裁剪规则但依赖自觉执行",
              "第 7 天设硬门：黄金路径未走通即冻结全部 AI 增强，只补 P0",
              "critical",
            ],
            [
              "演示截图涉及真实姓名、课程平台信息",
              "F12 要求示例数据，未定义脱敏标准",
              "统一用生成/虚构截图；真实上传不自动截图保存；隐私文案在 AI 分析前一次性确认（F11 第 364 行）",
              "medium",
            ],
          ]}
          rowTone={["critical", "warning", "warning", "default", "critical", "default"]}
        />
      </Stack>

      <Divider />

      <Stack gap={12}>
        <H2>七、15 天节奏（对 PRD 第 8 章的三处调整）</H2>
        <Grid columns={3} gap={12} minColumnWidth={220}>
          <Callout tone="info" title="调整 1：契约提前到第 1 天">
            <Text size="small">与 Pydantic 模型、fixture 同批产出，否则第 4 天前后端各自臆想字段。</Text>
          </Callout>
          <Callout tone="info" title="调整 2：planner 纯函数放第 4 天">
            <Text size="small">它独立于 UI、可单测、是 F13 P0 唯一有算法风险的部分；越晚做越贵。</Text>
          </Callout>
          <Callout tone="info" title="调整 3：演示模式与 fixture 合并做">
            <Text size="small">F12 的 5 份示例数据 = 前后端共用的那批 fixture，一次投入覆盖两个验收项。</Text>
          </Callout>
        </Grid>
        <Timeline
          density="compact"
          events={[
            {
              id: "p1",
              timestamp: "第 1–3 天",
              title: "最小可用链路",
              description:
                "脚手架 + 契约 v0.1 + F01 采集 + /analyze + Field 渲染 + 原图落 IndexedDB。里程碑：真实截图能出可编辑草稿。",
              state: "current",
              tone: "info",
            },
            {
              id: "p2",
              timestamp: "第 4–7 天",
              title: "信息整理闭环",
              description:
                "F03 字段确认 · F04 收集箱 · F05 手动归组 · F07 任务 · F08 今天 · planner.js 纯函数与测试 · F13 批量录入。第 7 天硬门：黄金路径未通即冻结 AI 增强。",
              state: "upcoming",
            },
            {
              id: "p3",
              timestamp: "第 8–11 天",
              title: "行动闭环",
              description:
                "F10 专注（计时 / 自动保存 / 恢复）· F13 草案预览与确认 · 今天↔计划条目↔专注三向联动 · 工时不足提示。",
              state: "upcoming",
            },
            {
              id: "p4",
              timestamp: "第 12–15 天",
              title: "稳定交付",
              description:
                "断网与异常回归 · F12 演示空间与脱敏素材 · 备份导出 · browser-use 跑通黄金路径逐条对验收清单 · 发布。",
              state: "upcoming",
            },
          ]}
        />
      </Stack>

      <Divider />

      <CollapsibleSection title="八、评审需当场拍板的决策项（PRD 第 9 章中与本设计强相关的 7 条）" defaultOpen={false}>
        <Table
          density="compact"
          headers={["#", "决策点", "本设计的默认取向", "若采纳相反结论要改哪里"]}
          rows={[
            ["1", "字段确认颗粒度", "关键三类（截止、提交材料、提交方式）独立确认，其余随整体审阅", "Note 详情页改为表单式全字段确认，F03 页面重构"],
            ["2", "便签唯一主要事项", "是，N:1", "改为 NoteMatter 关联表，搜索与归组筛选逻辑同步调整"],
            ["4", "删除事项时任务归属", "保留任务、解除关联、删除前提示", "加迁移对话框 + 批量迁移接口，约 0.5 天"],
            ["5", "任务截止时间出处", "记录 confirmed_from_note_id", "F06 的变更历史表可直接省掉，但演示讲不出依据"],
            ["7", "备份导出优先级", "提级 P0（最小 JSON+图片包）", "维持 P1 则必须承担现场数据丢失风险"],
            ["8", "演示数据隔离", "独立 workspace_id，退出即清", "共享空间则需引入「恢复真实数据」流程，复杂度显著上升"],
            ["13", "完成当日行动 ≠ 完成任务", "不自动完成，PlanItem 与 Task 各自独立进度", "自动完成会破坏 F13.4 第 450 行的双状态设计"],
            ["+A", "相对时间是否换算（新增）", "换算但标 derived + unresolved，UI 同屏显示原文", "完全不换算则「今天」的截止提醒在演示里全是空"],
          ]}
        />
      </CollapsibleSection>

      <Stack gap={10}>
        <H2>九、下一步</H2>
        <Text tone="secondary">选择一项交给 agent 继续，输出会回到当前对话。</Text>
        <Row gap={8} wrap>
          <SendToChatButton
            variant="primary"
            label="冻结契约 v0.1"
            text="按上面第五节的接口表，为「截下来」写 contract/schema.json、FastAPI 侧 Pydantic 模型骨架，以及 src/contract/typedefs.d.ts 的 JSDoc 声明，并生成 5 份前后端共用 fixture（对应 F12 的 5 份示例数据）。"
          />
          <SendToChatButton
            variant="secondary"
            label="搭 Vite + Vue3 脚手架"
            text="按上面第五节的目录建议创建 Vite + Vue 3 + JavaScript + Tailwind CSS 项目骨架，含 Pinia、persistence/idb.js（Blob + 元数据 + workspace_id 前缀 + storage.persist 申请）、domains/plan/planner.js 纯函数与 vitest 用例。不要写视觉设计，只搭骨架。"
          />
          <SendToChatButton
            variant="secondary"
            label="实现 planner 与 10 条边界测试"
            text="把 PRD F13.7 的 10 个异常边界场景转成 planner.test.js 用例，实现 domains/plan/planner.js，返回契约必须强制携带 gap_total，禁止在容量不足时返回看似完整的计划。"
          />
          <SendToChatButton
            variant="secondary"
            label="生成 F12 脱敏示例截图"
            text="用 imagegen 生成 5 张虚构的课程通知截图素材：课程作业通知、评分要求补充、截止时间变更、参考资料、以及一张实验要求，不要包含任何真实姓名、学校或平台标识。"
          />
        </Row>
      </Stack>

      <Text size="small" tone="tertiary">
        评审基线 v0.1 · 生成于 2026-11-17 · 源需求：截下来_V1_功能需求草案_v0.2_含多任务规划.md（讨论稿，未冻结）
      </Text>
    </Stack>
  );
}
