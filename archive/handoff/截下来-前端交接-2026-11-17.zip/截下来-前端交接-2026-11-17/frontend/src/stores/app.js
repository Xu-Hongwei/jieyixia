import { computed, ref, watch } from 'vue'
import { defineStore } from 'pinia'
import { allDocs, allSources, configureWorkspace, deleteNoteAtomic, getSource, putDoc, putSource, snapshot } from '@/services/storage/db'
import { analyze, blobToBase64, healthz } from '@/services/api/client'
import { canConfirm, failedNote, manualTask, mergeReanalysis, taskFromNote } from '@/domains/note'
import { isOverdue, isValidDate } from '@/domains/time'

const WORKSPACE = 'personal'
const UI_NOTE_KEY = 'jxl-ui-note'
const UI_EVIDENCE_KEY = 'jxl-ui-evidence'
const PENDING_SAVE_KEY = 'jxl-pending-save'

const readLocal = (key) => {
  try {
    return localStorage.getItem(key)
  } catch {
    return null
  }
}
const writeLocal = (key, value) => {
  try {
    if (value == null) localStorage.removeItem(key)
    else localStorage.setItem(key, value)
  } catch {
    // 隐私模式等场景 localStorage 不可用：UI 状态退化为仅本次会话
  }
}

export const useAppStore = defineStore('app', () => {
  const sources = ref([])
  const docs = ref([])
  const health = ref(null)
  const aiDown = ref(false)
  const busy = ref(false)
  const banner = ref(null)
  const pendingId = ref(null)
  const selectedNoteId = ref(readLocal(UI_NOTE_KEY))
  const evidenceOpen = ref(readLocal(UI_EVIDENCE_KEY) !== '0')
  const imageUrl = ref(null)
  const pendingSave = ref(JSON.parse(readLocal(PENDING_SAVE_KEY) || 'null'))

  const notes = computed(() => docs.value.filter((d) => d.kind === 'note'))
  const tasks = computed(() =>
    docs.value
      .filter((d) => d.kind === 'task')
      .slice()
      .sort((a, b) => Number(isOverdue(b)) - Number(isOverdue(a)) || String(a.deadline && a.deadline.value).localeCompare(String(b.deadline && b.deadline.value))),
  )
  const selectedNote = computed(() => notes.value.find((n) => n.id === selectedNoteId.value) || null)
  const pendingSource = computed(() => sources.value.find((s) => s.id === pendingId.value) || null)
  const unconfirmedCount = computed(() =>
    notes.value.reduce((acc, n) => acc + n.fields.filter((f) => f.status === 'candidate' || f.status === 'unresolved').length, 0),
  )

  const say = (tone, msg) => {
    banner.value = { tone, msg }
  }
  const now = () => new Date().toISOString()
  const fail = () => ({ ok: false, noteId: null })

  watch(selectedNoteId, (v) => writeLocal(UI_NOTE_KEY, v))
  watch(evidenceOpen, (v) => writeLocal(UI_EVIDENCE_KEY, v ? '1' : '0'))
  watch(pendingSave, (v) => writeLocal(PENDING_SAVE_KEY, v ? JSON.stringify(v) : null), { deep: true })

  async function reload() {
    sources.value = await allSources()
    docs.value = await allDocs()
    if (selectedNoteId.value && !notes.value.some((n) => n.id === selectedNoteId.value)) selectedNoteId.value = null
    if (!selectedNoteId.value && notes.value.length) await selectNote(notes.value[notes.value.length - 1].id)
    else if (selectedNoteId.value) await loadEvidence(selectedNote.value)
  }

  async function loadEvidence(note) {
    if (imageUrl.value) URL.revokeObjectURL(imageUrl.value)
    imageUrl.value = null
    if (!note || !note.source_id) return
    const source = await getSource(note.source_id)
    if (source && source.kind === 'image' && source.blob) imageUrl.value = URL.createObjectURL(source.blob)
  }

  async function selectNote(id) {
    selectedNoteId.value = id
    await loadEvidence(notes.value.find((n) => n.id === id) || null)
  }

  async function init() {
    configureWorkspace(WORKSPACE)
    await reload()
    const h = await healthz()
    if (h.ok) {
      health.value = h.body
      aiDown.value = !h.body.model_ready
    } else {
      health.value = null
      aiDown.value = true
    }
  }

  async function collectFiles(files) {
    for (const file of files) {
      if (!file.type.startsWith('image/')) {
        say('warning', `不支持的类型：${file.type || file.name}`)
        continue
      }
      const source = { id: crypto.randomUUID(), kind: 'image', captured_at: now(), blob: file, name: file.name }
      try {
        await putSource(source)
      } catch (err) {
        say('destructive', `保存失败（${err.message}）：原图未写入本地，请重试`)
        continue
      }
      sources.value.push(source)
      pendingId.value = source.id
      say('success', `原图已保存到本地（${file.name}），可「仅保存」留存或「AI 整理」`)
    }
  }

  async function collectText(text) {
    const trimmed = text.trim()
    if (!trimmed) {
      say('warning', '先粘贴或输入文字')
      return false
    }
    const source = { id: crypto.randomUUID(), kind: 'text', captured_at: now(), text: trimmed }
    try {
      await putSource(source)
    } catch (err) {
      say('destructive', `保存失败（${err.message}）：文字未写入本地`)
      return false
    }
    sources.value.push(source)
    pendingId.value = source.id
    say('success', '文字已保存到本地（未调用 AI）')
    return true
  }

  const upsertDoc = (doc) => {
    const idx = docs.value.findIndex((d) => d.id === doc.id)
    if (idx >= 0) docs.value[idx] = doc
    else docs.value.push(doc)
  }

  // 幂等：同一 source 重分析更新既有便签；落库失败暂存，重试仅落库不重调模型。
  async function runAnalysis(sourceId, referenceAt) {
    const source = sources.value.find((s) => s.id === sourceId)
    if (!source) {
      say('warning', '先收集一份截图或文字')
      return fail()
    }
    const refDate = (referenceAt || '').trim()
    if (refDate && !isValidDate(refDate)) {
      say('warning', '参照日期须为合法的 YYYY-MM-DD')
      return fail()
    }
    busy.value = true
    try {
      const payload = { source_id: source.id, kind: source.kind, captured_at: source.captured_at }
      if (refDate) payload.reference_at = refDate
      if (source.kind === 'image') payload.image_base64 = await blobToBase64(source.blob)
      else payload.text = source.text
      const result = await analyze(payload)
      if (result.ok) {
        const existing = notes.value.find((n) => n.source_id === source.id) || null
        const note = mergeReanalysis(existing, result.body, now())
        try {
          await putDoc(note)
        } catch (err) {
          pendingSave.value = note
          say('destructive', `保存失败（${err.message}）：分析结果已暂存，可重试保存（不重调模型）`)
          return { ok: false, saved: false, noteId: null }
        }
        pendingSave.value = null
        upsertDoc(note)
        pendingId.value = null
        await selectNote(note.id)
        say('success', `AI 草稿已生成：${note.fields.length} 个字段，待你核对确认`)
        return { ok: true, noteId: note.id }
      }
      if (result.status === 422) {
        const existing = notes.value.find((n) => n.source_id === source.id)
        if (existing) {
          say('destructive', `422 ${result.code}：本次分析未生效，既有便签与已确认字段保持不变，原图仍在本地`)
          return fail()
        }
        const note = failedNote(source.id, result.code, now())
        try {
          await putDoc(note)
        } catch (err) {
          pendingSave.value = note
          say('destructive', `保存失败（${err.message}）：失败记录已暂存，可重试保存（不重调模型）`)
          return { ok: false, saved: false, noteId: null }
        }
        upsertDoc(note)
        await selectNote(note.id)
        say('destructive', `422 ${result.code}：原图仍在本地，可重试或手动整理`)
        return { ok: false, noteId: note.id }
      }
      if (result.status === 503) {
        aiDown.value = true
        say('warning', '模型不可用：AI 入口已隐藏，「仅保存」与本地浏览不受影响')
        return fail()
      }
      if (result.status === 413) {
        say('warning', '图片超出体积上限：请压缩后重试，原图已在本地')
        return fail()
      }
      if (result.kind === 'network') {
        say('destructive', `网络错误：${result.message}（本地数据不受影响）`)
        return fail()
      }
      say('destructive', `意外状态 ${result.status}`)
      return fail()
    } finally {
      busy.value = false
    }
  }

  async function retrySave() {
    const note = pendingSave.value
    if (!note) return fail()
    try {
      await putDoc(note)
    } catch (err) {
      say('destructive', `保存失败（${err.message}）：分析结果仍在暂存，可再次重试（不重调模型）`)
      return fail()
    }
    pendingSave.value = null
    upsertDoc(note)
    pendingId.value = null
    await selectNote(note.id)
    say('success', '分析结果已保存（重试仅落库，未重调模型）')
    return { ok: true, noteId: note.id }
  }

  // 按文档 id 串行化变更：每次从最新已提交状态克隆再改，连续确认不丢修改。
  const mutationChains = new Map()
  function mutateNote(note, fn) {
    const id = note.id
    const prev = mutationChains.get(id) || Promise.resolve()
    const run = prev.catch(() => {}).then(async () => {
      const current = docs.value.find((d) => d.id === id) || note
      const draft = snapshot(current)
      fn(draft)
      draft.updated_at = now()
      try {
        await putDoc(draft)
      } catch (err) {
        say('destructive', `保存失败（${err.message}）：修改未持久化，界面保持原样`)
        return false
      }
      upsertDoc(draft)
      return true
    })
    mutationChains.set(id, run)
    run.finally(() => {
      if (mutationChains.get(id) === run) mutationChains.delete(id)
    })
    return run
  }

  function confirmField(note, key) {
    const f = note.fields.find((x) => x.key === key)
    if (!f || !canConfirm(f)) {
      say('warning', '空值或终态字段不可确认为事实')
      return Promise.resolve(false)
    }
    return mutateNote(note, (n) => {
      const target = n.fields.find((x) => x.key === key)
      target.status = 'confirmed' // D4：确认不改 origin；推算值保留 derived 与原文
    })
  }

  const saveEdit = (note, key, value) =>
    mutateNote(note, (n) => {
      const f = n.fields.find((x) => x.key === key)
      f.value = Array.isArray(f.value) ? value.split('\n').filter(Boolean) : value
      f.origin = 'user'
    })

  const saveNodeEdit = (note, index, e) =>
    mutateNote(note, (n) => {
      const f = n.fields.find((x) => x.key === 'time_nodes')
      const old = f.value[index]
      const v = (e.value || '').trim()
      f.value[index] = {
        ...old,
        label: (e.label || '').trim(),
        value: v || null,
        basis: e.basis,
        role: e.role,
        reference_at: e.reference_at || null,
        reference_source: e.reference_source || null,
        message_date: e.message_date || null,
        precision: v ? (v.includes('T') ? 'datetime' : 'date') : null,
        tz_known: v && v.includes('T') ? /([+-]\d{2}:\d{2}|Z)$/.test(v) : null,
        derived: e.basis === 'relative' || e.basis === 'inferred',
      }
    })

  const reviewNote = (note) => mutateNote(note, (n) => { n.status = 'reviewed'; n.reviewed_at = now() })

  async function createTask(note) {
    const task = taskFromNote(note, now())
    if (!task) {
      say('warning', '先独立确认截止时间，才能把它带进任务（出处可追溯）')
      return { ok: false }
    }
    try {
      await putDoc(task)
    } catch (err) {
      say('destructive', `保存失败（${err.message}）：任务未持久化`)
      return { ok: false }
    }
    upsertDoc(task)
    say('success', '任务已创建，截止时间来自已确认的便签字段')
    return { ok: true }
  }

  async function createTaskManual(note, value) {
    const task = manualTask(note, value.trim(), now())
    if (!task) {
      say('warning', '手动截止须为合法的 YYYY-MM-DD 或 ISO datetime（日历与时钟都要合法）')
      return { ok: false }
    }
    try {
      await putDoc(task)
    } catch (err) {
      say('destructive', `保存失败（${err.message}）：任务未持久化`)
      return { ok: false }
    }
    upsertDoc(task)
    say('success', '任务已创建（截止为用户手动输入，已记录确认时间）')
    return { ok: true }
  }

  async function finishTask(task) {
    const draft = snapshot(task)
    draft.status = 'done'
    draft.updated_at = now()
    try {
      await putDoc(draft)
    } catch (err) {
      say('destructive', `保存失败（${err.message}）：状态未持久化，界面保持原样`)
      return { ok: false }
    }
    upsertDoc(draft)
    return { ok: true }
  }

  async function deleteNote(note) {
    const affected = tasks.value.filter((t) => t.deadline && t.deadline.from_note_id === note.id)
    if (affected.length) {
      say('destructive', `不能删除：${affected.length} 个任务的截止引用此便签（${affected.map((t) => t.title).join('、')}）。请先更换截止来源`)
      return { ok: false }
    }
    const linked = tasks.value.filter((t) => (t.note_ids || []).includes(note.id))
    const drafts = linked.map((t) => {
      const draft = snapshot(t)
      draft.note_ids = draft.note_ids.filter((id) => id !== note.id)
      draft.updated_at = now()
      return draft
    })
    try {
      await deleteNoteAtomic(note.id, drafts)
    } catch (err) {
      say('destructive', `删除失败（${err.message}）：便签与任务关联均未改动`)
      return { ok: false }
    }
    for (const draft of drafts) upsertDoc(draft)
    docs.value = docs.value.filter((d) => d.id !== note.id)
    if (selectedNoteId.value === note.id) selectedNoteId.value = null
    say('success', '便签已删除；任务关联已解除，原始资料保留')
    return { ok: true }
  }

  return {
    sources, docs, health, aiDown, busy, banner, pendingId, selectedNoteId, evidenceOpen, imageUrl, pendingSave,
    notes, tasks, selectedNote, pendingSource, unconfirmedCount,
    say, init, reload, selectNote, collectFiles, collectText, runAnalysis, retrySave,
    confirmField, saveEdit, saveNodeEdit, reviewNote, createTask, createTaskManual, finishTask, deleteNote,
  }
})