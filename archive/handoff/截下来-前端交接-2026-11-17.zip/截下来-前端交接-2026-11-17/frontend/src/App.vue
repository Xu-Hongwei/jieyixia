<script setup>
import { onMounted } from 'vue'
import { RouterLink, RouterView, useRoute } from 'vue-router'
import { CirclePlay, Inbox, NotebookPen, Sun } from 'lucide-vue-next'
import Alert from '@/components/ui/Alert.vue'
import Badge from '@/components/ui/Badge.vue'
import { useAppStore } from '@/stores/app'

const store = useAppStore()
const route = useRoute()
onMounted(() => store.init())
</script>

<template>
  <div class="flex min-h-screen">
    <aside class="hidden w-52 shrink-0 flex-col border-r bg-card md:flex">
      <div class="flex items-center gap-2 px-4 py-4">
        <span class="flex size-7 items-center justify-center rounded-md bg-primary text-sm font-bold text-primary-foreground">截</span>
        <strong class="text-sm">截下来</strong>
      </div>
      <div class="px-4 pb-3 text-xs text-muted-foreground">个人工作区 · 本地存储</div>
      <nav class="flex-1 space-y-1 px-2">
        <RouterLink to="/today" class="flex items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-accent" active-class="bg-accent font-medium">
          <Sun class="size-4" />今天
        </RouterLink>
        <RouterLink to="/collect" class="flex items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-accent" active-class="bg-accent font-medium">
          <Inbox class="size-4" />收集箱
          <span v-if="store.sources.length" class="ml-auto text-xs text-muted-foreground">{{ store.sources.length }}</span>
        </RouterLink>
        <RouterLink to="/notes" class="flex items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-accent" active-class="bg-accent font-medium">
          <NotebookPen class="size-4" />便签核对
          <span v-if="store.unconfirmedCount" class="ml-auto rounded-full bg-warning px-1.5 text-xs text-warning-foreground">{{ store.unconfirmedCount }}</span>
        </RouterLink>
        <span class="flex cursor-not-allowed items-center gap-2 rounded-md px-2 py-1.5 text-sm text-muted-foreground" title="专注工作区：后续 P0 交付">
          <CirclePlay class="size-4" />专注
          <span class="ml-auto text-xs">后续</span>
        </span>
      </nav>
      <div class="px-4 py-3 text-xs text-muted-foreground">数据仅存本浏览器<br />刷新 / 重开可恢复</div>
    </aside>

    <div class="min-w-0 flex-1">
      <header class="flex flex-wrap items-center gap-2 border-b px-4 py-3">
        <nav class="flex gap-1 md:hidden">
          <RouterLink to="/today" class="rounded-md px-2 py-1 text-sm" active-class="bg-accent font-medium">今天</RouterLink>
          <RouterLink to="/collect" class="rounded-md px-2 py-1 text-sm" active-class="bg-accent font-medium">收集</RouterLink>
          <RouterLink to="/notes" class="rounded-md px-2 py-1 text-sm" active-class="bg-accent font-medium">核对</RouterLink>
        </nav>
        <span class="hidden text-sm font-medium md:inline">{{ route.meta.title }}</span>
        <span class="flex-1" />
        <Badge v-if="!store.health" variant="destructive">后端不可达 · 离线可用</Badge>
        <Badge v-else-if="store.aiDown" variant="warning">AI 暂不可用 · 契约 {{ store.health.schema_version }}</Badge>
        <Badge v-else variant="success">模型就绪 · 契约 {{ store.health.schema_version }}</Badge>
      </header>

      <div v-if="store.banner" class="px-4 pt-3">
        <Alert :variant="store.banner.tone">{{ store.banner.msg }}</Alert>
      </div>

      <main class="p-4">
        <RouterView />
      </main>
    </div>
  </div>
</template>