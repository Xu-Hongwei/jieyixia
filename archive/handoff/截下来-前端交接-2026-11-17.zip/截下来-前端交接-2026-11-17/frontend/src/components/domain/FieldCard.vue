<script setup>
import { ref } from 'vue'
import { Check, Pencil } from 'lucide-vue-next'
import Badge from '@/components/ui/Badge.vue'
import Button from '@/components/ui/Button.vue'
import Input from '@/components/ui/Input.vue'
import NodeSelect from '@/components/domain/NodeSelect.vue'
import { useAppStore } from '@/stores/app'
import { canConfirm } from '@/domains/note'
import { formatWhen, isValidDate, isValidTimeValue } from '@/domains/time'
import { BASIS_LABELS, FIELD_LABELS, REF_SOURCE_LABELS, ROLE_LABELS, STATUS_LABELS, label } from '@/domains/labels'

const props = defineProps({
  note: { type: Object, required: true },
  field: { type: Object, required: true },
})
const store = useAppStore()

const statusVariant = { candidate: 'warning', confirmed: 'success', unresolved: 'outline', missing: 'muted' }
const editing = ref(false)
const editValue = ref('')
const nodeEdit = ref(null)

const roleItems = Object.entries(ROLE_LABELS).map(([value, labelText]) => ({ value, label: labelText }))
const basisItems = Object.entries(BASIS_LABELS).map(([value, labelText]) => ({ value, label: labelText }))
const refItems = [
  { value: 'none', label: '无参照' },
  { value: 'message_date', label: '消息日期' },
  { value: 'user', label: '用户指定' },
]

function startEdit() {
  editValue.value = Array.isArray(props.field.value)
    ? props.field.value.join('\n')
    : props.field.value == null ? '' : String(props.field.value)
  editing.value = true
}
async function saveEdit() {
  const ok = await store.saveEdit(props.note, props.field.key, editValue.value)
  if (ok) editing.value = false
}

function displayValue(f) {
  if (f.value == null) return f.status === 'missing' ? '原文未提' : '（空 · 待确认）'
  if (f.key === 'deadline') return formatWhen(f.value, f.precision)
  if (Array.isArray(f.value)) return f.value.join('；')
  return String(f.value)
}

function startNodeEdit(i) {
  const n = props.field.value[i]
  nodeEdit.value = {
    index: i,
    label: n.label || '',
    value: n.value || '',
    role: n.role || 'unknown',
    basis: n.basis || 'explicit',
    reference_at: n.reference_at || '',
    reference_source: n.reference_source || 'none',
    message_date: n.message_date || '',
  }
}
async function saveNodeEdit() {
  const e = nodeEdit.value
  const v = e.value.trim()
  if (v && !isValidTimeValue(v)) return store.say('warning', '节点值须为合法的日期或 ISO datetime；留空表示待确认')
  for (const k of ['reference_at', 'message_date']) {
    if (e[k] && !isValidDate(e[k])) return store.say('warning', '参照 / 消息日期须为合法的 YYYY-MM-DD')
  }
  const ok = await store.saveNodeEdit(props.note, e.index, {
    ...e,
    value: v,
    reference_source: e.reference_source === 'none' ? '' : e.reference_source,
  })
  if (ok) nodeEdit.value = null
}
</script>

<template>
  <div class="rounded-lg border p-3 space-y-1.5">
    <div class="flex flex-wrap items-center gap-2">
      <span class="text-sm font-medium">{{ label(FIELD_LABELS, field.key) }}</span>
      <Badge :variant="statusVariant[field.status]" :title="field.status">{{ label(STATUS_LABELS, field.status) }}</Badge>
      <Badge v-if="field.derived" variant="outline" title="derived">推算</Badge>
      <Badge v-if="field.precision === 'datetime' && field.tz_known === false" variant="warning">时区未知</Badge>
      <Badge v-if="field.origin === 'user'" variant="secondary" title="origin=user">用户修改</Badge>
      <span class="flex-1" />
      <Button v-if="canConfirm(field)" size="sm" variant="outline" @click="store.confirmField(note, field.key)"><Check />确认</Button>
      <Button v-if="field.key !== 'time_nodes'" size="sm" variant="ghost" @click="startEdit"><Pencil />编辑</Button>
    </div>

    <Input v-if="editing" v-model="editValue" @keyup.enter="saveEdit" />
    <div v-else-if="field.key === 'time_nodes' && Array.isArray(field.value)" class="space-y-1.5">
      <div v-for="(n, i) in field.value" :key="i" class="rounded-md border p-2 space-y-1">
        <div class="flex flex-wrap items-center gap-2 text-sm">
          <Badge variant="secondary">{{ n.label || '节点' + (i + 1) }}</Badge>
          <span>{{ n.value ? formatWhen(n.value, n.precision) : '（待确认）' }}</span>
          <Badge v-if="n.basis === 'superseded'" variant="muted" :title="n.basis">已取代</Badge>
          <Badge v-else-if="n.basis && n.basis !== 'explicit'" variant="outline" :title="n.basis">{{ label(BASIS_LABELS, n.basis) }}</Badge>
          <Badge variant="outline" :title="n.role">{{ label(ROLE_LABELS, n.role || 'unknown') }}</Badge>
          <span class="flex-1" />
          <Button size="sm" variant="ghost" @click="startNodeEdit(i)"><Pencil />编辑节点</Button>
        </div>
        <div class="text-xs text-muted-foreground">原文：{{ n.raw }}</div>
        <div v-if="n.reference_at" class="text-xs text-muted-foreground">
          参照 {{ n.reference_at }}（{{ label(REF_SOURCE_LABELS, n.reference_source) }}）<template v-if="n.message_date"> · 消息日期 {{ n.message_date }}</template>
        </div>
        <div v-if="nodeEdit && nodeEdit.index === i" class="grid gap-2 sm:grid-cols-2">
          <Input v-model="nodeEdit.label" placeholder="标签" />
          <Input v-model="nodeEdit.value" placeholder="值 YYYY-MM-DD 或 ISO datetime（可空）" />
          <NodeSelect v-model="nodeEdit.role" :items="roleItems" placeholder="节点角色" />
          <NodeSelect v-model="nodeEdit.basis" :items="basisItems" placeholder="时间依据" />
          <Input v-model="nodeEdit.reference_at" placeholder="参照日期 YYYY-MM-DD（可空）" />
          <NodeSelect v-model="nodeEdit.reference_source" :items="refItems" placeholder="参照来源" />
          <Input v-model="nodeEdit.message_date" placeholder="消息日期 YYYY-MM-DD（可空）" />
          <div class="flex gap-2">
            <Button size="sm" @click="saveNodeEdit">保存节点</Button>
            <Button size="sm" variant="ghost" @click="nodeEdit = null">取消</Button>
          </div>
        </div>
      </div>
    </div>
    <div v-else class="text-sm">{{ displayValue(field) }}</div>

    <div v-if="field.quote" class="text-xs text-muted-foreground">原文引用：「{{ field.quote.text }}」</div>
    <div v-if="editing" class="flex gap-2">
      <Button size="sm" @click="saveEdit">保存修改</Button>
      <Button size="sm" variant="ghost" @click="editing = false">取消</Button>
    </div>
    <details class="text-xs">
      <summary class="cursor-pointer text-muted-foreground">查看原始数据</summary>
      <pre class="mt-1 overflow-auto rounded-md bg-muted p-2">{{ JSON.stringify(field, null, 2) }}</pre>
    </details>
  </div>
</template>