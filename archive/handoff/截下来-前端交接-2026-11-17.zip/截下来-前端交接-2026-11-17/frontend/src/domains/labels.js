// 产品中文文案：内部枚举只作技术标注（title/详情），不作普通用户文案。
export const FIELD_LABELS = {
  title: '标题',
  deadline: '截止时间',
  requirement: '需要提交',
  constraints: '要求',
  submit_to: '提交入口',
  reminder: '提醒',
  time_nodes: '时间节点',
  summary: '摘要',
  steps: '步骤',
  cautions: '注意事项',
  keywords: '关键词',
}

export const STATUS_LABELS = {
  candidate: '待核对',
  confirmed: '已确认',
  unresolved: '待确认',
  missing: '原文未提',
  draft: '草稿',
  reviewed: '已审阅',
  failed: '分析失败',
  pending: '待处理',
  todo: '待办',
  done: '已完成',
}

export const ROLE_LABELS = {
  submission_deadline: '提交截止',
  event_start: '活动开始',
  event_end: '活动结束',
  other: '其他',
  unknown: '未分类',
}

export const BASIS_LABELS = {
  explicit: '原文写明',
  relative: '相对换算',
  inferred: '补年推断',
  superseded: '已取代',
}

export const REF_SOURCE_LABELS = {
  user: '用户指定',
  message_date: '消息日期',
}

export const CONTENT_TYPE_LABELS = {
  notice: '通知',
  tutorial: '教程',
  reference: '参考资料',
}

export const label = (map, key) => map[key] || key