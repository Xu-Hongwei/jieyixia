// 时间规则（与契约 0.3.0 同口径）：形状正则 + 真日历探针；逾期 date 型本地次日起算。
export function isValidTimeValue(v) {
  const m = /^(\d{4})-(\d{2})-(\d{2})(T(\d{2}):(\d{2})(:(\d{2}))?([+-]\d{2}:\d{2}|Z)?)?$/.exec(v)
  if (!m) return false
  const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]))
  if (d.getUTCFullYear() !== +m[1] || d.getUTCMonth() !== +m[2] - 1 || d.getUTCDate() !== +m[3]) return false
  if (m[4] && (+m[5] > 23 || +m[6] > 59 || (m[8] && +m[8] > 59))) return false
  if (m[9] && m[9] !== 'Z' && (+m[9].slice(1, 3) > 23 || +m[9].slice(4, 6) > 59)) return false
  return true
}

export const isValidDate = (v) => /^\d{4}-\d{2}-\d{2}$/.test(v) && isValidTimeValue(v)

export function isOverdue(task, nowD = new Date()) {
  const dl = task.deadline
  if (!dl || !dl.value || task.status === 'done') return false
  if (dl.precision === 'date') {
    const today = new Date(nowD.getFullYear(), nowD.getMonth(), nowD.getDate())
    return new Date(dl.value + 'T00:00:00') < today
  }
  return new Date(dl.value) < nowD
}

export function formatWhen(value, precision) {
  if (!value) return ''
  const m = /^(\d{4})-(\d{2})-(\d{2})(T(\d{2}):(\d{2}))?/.exec(value)
  if (!m) return value
  const date = `${+m[1]}年${+m[2]}月${+m[3]}日`
  if (precision === 'date' || !m[4]) return date
  return `${date} ${m[5]}:${m[6]}`
}