import { isValidTimeValue } from './time'

/** @typedef {import('@contract/typedefs').Field} Field */
/** @typedef {import('@contract/typedefs').Note} Note */
/** @typedef {import('@contract/typedefs').AnalyzeResponse} AnalyzeResponse */
/** @typedef {import('@contract/typedefs').Task} Task */

// null 不可确认为事实；missing 是终态；已确认不重复确认。
export const canConfirm = (field) =>
  field.value != null && field.status !== 'confirmed' && field.status !== 'missing'

// 幂等重分析：同一 source 更新既有便签而非新建第二份；
// 已确认 / 用户改过的字段不被模型覆盖（AI 不得改写人工事实）。
export function mergeReanalysis(oldNote, body, now) {
  const fields = body.fields.map((nf) => {
    const old = oldNote && oldNote.fields.find((f) => f.key === nf.key)
    if (old && (old.status === 'confirmed' || old.origin === 'user')) return old
    return nf
  })
  // 新结果可能省略某键（如无可靠参照时后端移除 deadline）；已确认/用户改过的旧字段必须保留，不被丢弃
  if (oldNote) {
    for (const old of oldNote.fields) {
      if ((old.status === 'confirmed' || old.origin === 'user') && !fields.some((f) => f.key === old.key)) fields.push(old)
    }
  }
  const titleField = fields.find((f) => f.key === 'title')
  return {
    id: oldNote ? oldNote.id : crypto.randomUUID(),
    kind: 'note',
    source_id: body.source_id,
    status: 'draft',
    content_type: body.content_type,
    title: (titleField && titleField.value) || (oldNote && oldNote.title) || '未命名便签',
    fields,
    warnings: body.warnings || [],
    created_at: oldNote ? oldNote.created_at : now,
    updated_at: now,
  }
}

export function failedNote(sourceId, code, now) {
  return {
    id: crypto.randomUUID(),
    kind: 'note',
    source_id: sourceId,
    status: 'failed',
    content_type: 'reference',
    title: '分析失败（原图保留）',
    fields: [],
    warnings: [],
    created_at: now,
    updated_at: now,
    error: code,
  }
}

// 截止必须来自已确认字段，出处可追溯；未确认返回 null，由界面提示先确认。
export function taskFromNote(note, now) {
  const dl = note.fields.find((f) => f.key === 'deadline' && f.status === 'confirmed' && f.value != null)
  if (!dl) return null
  return {
    id: crypto.randomUUID(),
    kind: 'task',
    title: note.title,
    note_ids: [note.id],
    deadline: {
      value: dl.value,
      precision: dl.precision || (String(dl.value).includes('T') ? 'datetime' : 'date'),
      source: 'note',
      from_note_id: note.id,
      confirmed_at: now,
    },
    status: 'todo',
    created_at: now,
    updated_at: now,
  }
}

export function manualTask(note, value, now) {
  if (!isValidTimeValue(value)) return null
  return {
    id: crypto.randomUUID(),
    kind: 'task',
    title: note.title,
    note_ids: [note.id],
    deadline: {
      value,
      precision: value.includes('T') ? 'datetime' : 'date',
      source: 'manual',
      confirmed_at: now,
    },
    status: 'todo',
    created_at: now,
    updated_at: now,
  }
}