import 'fake-indexeddb/auto'
import { beforeEach, describe, expect, it } from 'vitest'
import { reactive, isReactive } from 'vue'
import { allDocs, configureWorkspace, deepRaw, deleteNoteAtomic, putDoc, snapshot } from '../services/storage/db'

beforeEach(() => configureWorkspace('w1'))

describe('workspace 限定', () => {
  it('读写都按当前空间过滤，跨空间写入拒绝', async () => {
    await putDoc({ id: 'a', kind: 'note', title: 'w1 便签' })
    configureWorkspace('w2')
    expect(await allDocs()).toHaveLength(0)
    await expect(putDoc({ id: 'b', kind: 'note', workspace_id: 'w1' })).rejects.toThrow()
    configureWorkspace('w1')
    expect((await allDocs()).map((d) => d.id)).toEqual(['a'])
  })
})

describe('快照深脱代理', () => {
  it('嵌套 reactive 可结构化克隆且落库非响应式', () => {
    const nested = reactive({ list: reactive([{ x: 1 }]), when: new Date() })
    const snap = snapshot(nested)
    expect(isReactive(snap)).toBe(false)
    expect(isReactive(snap.list)).toBe(false)
    expect(snap.list[0].x).toBe(1)
    expect(deepRaw(nested).when).toBeInstanceOf(Date)
  })
})

describe('原子删除事务', () => {
  it('任务写入失败整体回滚：便签仍在、关联不变', async () => {
    await putDoc({ id: 'note-x', kind: 'note', title: 'n' })
    await putDoc({ id: 'task-x', kind: 'task', title: 't', note_ids: ['note-x'] })
    const origPut = IDBObjectStore.prototype.put
    IDBObjectStore.prototype.put = function (value, ...rest) {
      if (value && value.kind === 'task') throw new Error('注入写入失败')
      return origPut.call(this, value, ...rest)
    }
    try {
      await expect(deleteNoteAtomic('note-x', [{ id: 'task-x', kind: 'task', note_ids: [] }])).rejects.toThrow()
    } finally {
      IDBObjectStore.prototype.put = origPut
    }
    const docs = await allDocs()
    expect(docs.find((d) => d.id === 'note-x')).toBeTruthy()
    expect(docs.find((d) => d.id === 'task-x').note_ids).toEqual(['note-x'])
  })
  it('成功路径：便签删除且关联解除', async () => {
    await deleteNoteAtomic('note-x', [{ id: 'task-x', kind: 'task', title: 't', note_ids: [] }])
    const docs = await allDocs()
    expect(docs.find((d) => d.id === 'note-x')).toBeUndefined()
    expect(docs.find((d) => d.id === 'task-x').note_ids).toEqual([])
  })
})