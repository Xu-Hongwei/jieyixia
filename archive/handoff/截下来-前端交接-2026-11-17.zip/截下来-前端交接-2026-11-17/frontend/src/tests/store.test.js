import 'fake-indexeddb/auto'
import { beforeEach, describe, expect, it } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { useAppStore } from '../stores/app'
import { putDoc } from '../services/storage/db'

beforeEach(() => setActivePinia(createPinia()))

describe('连续确认不丢修改（串行化）', () => {
  it('同一 tick 确认两个字段都落库', async () => {
    const store = useAppStore()
    await store.init()
    await putDoc({
      id: 'note-serial', kind: 'note', title: 't', status: 'draft',
      fields: [
        { key: 'title', value: 't', status: 'candidate', origin: 'model' },
        { key: 'requirement', value: 'PDF', status: 'candidate', origin: 'model' },
      ],
      warnings: [],
    })
    await store.reload()
    const note = store.notes.find((n) => n.id === 'note-serial')
    await Promise.all([store.confirmField(note, 'title'), store.confirmField(note, 'requirement')])
    const after = store.notes.find((n) => n.id === 'note-serial')
    expect(after.fields.every((f) => f.status === 'confirmed')).toBe(true)
  })
  it('确认推算值保留 origin=model 与 derived（D4）', async () => {
    const store = useAppStore()
    await store.init()
    await putDoc({
      id: 'note-d4', kind: 'note', title: 't', status: 'draft',
      fields: [{ key: 'deadline', value: '2026-11-20T17:00', status: 'unresolved', origin: 'model', derived: true }],
      warnings: [],
    })
    await store.reload()
    const note = store.notes.find((n) => n.id === 'note-d4')
    await store.confirmField(note, 'deadline')
    const f = store.notes.find((n) => n.id === 'note-d4').fields[0]
    expect(f.status).toBe('confirmed')
    expect(f.origin).toBe('model')
    expect(f.derived).toBe(true)
  })
})