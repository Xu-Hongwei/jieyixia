import { describe, expect, it } from 'vitest'
import { isOverdue, isValidDate, isValidTimeValue } from '../domains/time'

describe('isValidTimeValue 形状 + 日历 + 时钟 + 偏移', () => {
  it('合法日期与 datetime', () => {
    expect(isValidTimeValue('2026-11-20')).toBe(true)
    expect(isValidTimeValue('2026-11-20T17:00')).toBe(true)
    expect(isValidTimeValue('2026-11-20T17:00:00+08:00')).toBe(true)
    expect(isValidTimeValue('2026-11-20T17:00:00Z')).toBe(true)
  })
  it('日历非法拒绝', () => {
    expect(isValidTimeValue('2026-02-30')).toBe(false)
    expect(isValidTimeValue('2026-13-01')).toBe(false)
  })
  it('时钟非法拒绝', () => {
    expect(isValidTimeValue('2026-11-20T25:00')).toBe(false)
    expect(isValidTimeValue('2026-11-20T17:75')).toBe(false)
  })
  it('UTC 偏移非法拒绝', () => {
    expect(isValidTimeValue('2026-11-20T17:00:00+99:99')).toBe(false)
    expect(isValidTimeValue('2026-11-20T17:00:00+08:75')).toBe(false)
  })
  it('isValidDate 只收日期', () => {
    expect(isValidDate('2026-11-20')).toBe(true)
    expect(isValidDate('2026-11-20T17:00')).toBe(false)
  })
})

describe('isOverdue 口径', () => {
  const now = new Date('2026-11-18T10:00:00+08:00')
  it('date 型当天不判逾期，次日起算', () => {
    expect(isOverdue({ status: 'todo', deadline: { value: '2026-11-18', precision: 'date' } }, now)).toBe(false)
    expect(isOverdue({ status: 'todo', deadline: { value: '2026-11-17', precision: 'date' } }, now)).toBe(true)
  })
  it('datetime 带时区按绝对时刻', () => {
    expect(isOverdue({ status: 'todo', deadline: { value: '2026-11-18T01:00:00Z', precision: 'datetime' } }, now)).toBe(true)
    expect(isOverdue({ status: 'todo', deadline: { value: '2026-11-18T12:00:00+08:00', precision: 'datetime' } }, now)).toBe(false)
  })
  it('done 不判逾期', () => {
    expect(isOverdue({ status: 'done', deadline: { value: '2026-11-01', precision: 'date' } }, now)).toBe(false)
  })
})