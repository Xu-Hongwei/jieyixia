<script setup>
import { RouterLink } from 'vue-router'
import { Clock } from 'lucide-vue-next'
import Badge from '@/components/ui/Badge.vue'
import Button from '@/components/ui/Button.vue'
import Card from '@/components/ui/Card.vue'
import { useAppStore } from '@/stores/app'
import { isOverdue, formatWhen } from '@/domains/time'
import { STATUS_LABELS, label } from '@/domains/labels'

const store = useAppStore()

function deadlineSource(t) {
  if (!t.deadline) return '无截止'
  if (t.deadline.source === 'manual') return '用户手动输入'
  const note = store.notes.find((n) => n.id === t.deadline.from_note_id)
  return note ? `来自便签「${note.title}」` : '来自便签'
}
</script>

<template>
  <div class="space-y-4">
    <Card v-if="store.unconfirmedCount">
      <div class="flex flex-wrap items-center gap-2 text-sm">
        <span>有 {{ store.unconfirmedCount }} 个字段待你核对确认。</span>
        <RouterLink to="/notes" class="underline">去核对</RouterLink>
      </div>
    </Card>

    <Card>
      <template #header>
        <div class="text-base font-semibold">今天 · 任务</div>
        <p class="text-sm text-muted-foreground">逾期优先。截止时间带出处，可追溯；完成任务不改变便签事实。</p>
      </template>
      <div class="space-y-2">
        <div v-for="t in store.tasks" :key="t.id" class="flex flex-wrap items-center gap-3 rounded-md border p-3">
          <Clock v-if="isOverdue(t)" class="size-4 text-red-600" />
          <div class="min-w-0 flex-1">
            <div class="text-sm font-medium">{{ t.title }}</div>
            <div class="text-xs text-muted-foreground">
              截止 {{ t.deadline ? formatWhen(t.deadline.value, t.deadline.precision) : '无' }} · {{ deadlineSource(t) }}
            </div>
          </div>
          <Badge v-if="isOverdue(t)" variant="destructive">已逾期</Badge>
          <Badge :variant="t.status === 'done' ? 'success' : 'secondary'" :title="t.status">{{ label(STATUS_LABELS, t.status) }}</Badge>
          <Button v-if="t.status !== 'done'" size="sm" variant="outline" @click="store.finishTask(t)">完成</Button>
        </div>
        <p v-if="!store.tasks.length" class="text-sm text-muted-foreground">
          还没有任务。<RouterLink to="/collect" class="underline">去收集</RouterLink>资料，核对确认截止后建任务。
        </p>
      </div>
    </Card>
  </div>
</template>