<script setup>
import { onMounted, onUnmounted, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import { RefreshCw, Sparkles, Upload } from 'lucide-vue-next'
import Alert from '@/components/ui/Alert.vue'
import Button from '@/components/ui/Button.vue'
import Card from '@/components/ui/Card.vue'
import Input from '@/components/ui/Input.vue'
import Textarea from '@/components/ui/Textarea.vue'
import { useAppStore } from '@/stores/app'

const store = useAppStore()
const router = useRouter()
const textDraft = ref('')
const referenceAt = ref('')
const fileInput = ref(null)
const pendingUrl = ref(null)

watch(() => store.pendingSource, (s) => {
  if (pendingUrl.value) URL.revokeObjectURL(pendingUrl.value)
  pendingUrl.value = s && s.kind === 'image' && s.blob ? URL.createObjectURL(s.blob) : null
}, { immediate: true })

async function runAI() {
  const draft = textDraft.value.trim()
  let source = store.pendingSource
  // 文字草稿先落本地再调 AI（先保存原始资料）；图片在选择时已落本地，直接分析待处理图片
  if (draft && (!source || (source.kind === 'text' && source.text !== draft))) {
    const saved = await store.collectText(draft)
    if (!saved) return
    textDraft.value = ''
    source = store.pendingSource
  }
  if (!source) return store.say('warning', '先收集一份截图或文字')
  const result = await store.runAnalysis(source.id, referenceAt.value)
  // 成功或 422 生成失败记录时都跳转到便签（失败记录提供「重试分析」下一步）；
  // 503/413/网络/落库失败 noteId 为 null，留在收集页看横幅与重试入口。
  if (result && result.noteId) router.push('/notes/' + result.noteId)
}
async function retrySave() {
  const result = await store.retrySave()
  if (result && result.ok) router.push('/notes/' + result.noteId)
}
async function saveText() {
  const ok = await store.collectText(textDraft.value)
  if (ok) textDraft.value = ''
}

function onPaste(e) {
  if (e.target.closest('textarea, input')) return
  const files = e.clipboardData && e.clipboardData.files
  if (files && files.length) {
    e.preventDefault()
    store.collectFiles(files)
  } else {
    const text = e.clipboardData && e.clipboardData.getData('text')
    if (text) {
      textDraft.value = text
      store.say('info', '剪贴板文字已填入输入框')
    }
  }
}
const onDrop = (e) => {
  e.preventDefault()
  store.collectFiles(e.dataTransfer.files)
}
function onFileChange(e) {
  const input = /** @type {HTMLInputElement} */ (e.target)
  store.collectFiles(input.files)
  input.value = ''
}
onMounted(() => window.addEventListener('paste', onPaste))
onUnmounted(() => {
  window.removeEventListener('paste', onPaste)
  if (pendingUrl.value) URL.revokeObjectURL(pendingUrl.value)
})
</script>

<template>
  <Card @drop="onDrop" @dragover.prevent>
    <template #header>
      <div class="text-base font-semibold">收集原始资料</div>
      <p class="text-sm text-muted-foreground">Ctrl+V 粘贴截图 / 拖入 / 选择文件 / 粘贴文字。原图先落本地，再决定是否 AI 整理。</p>
    </template>
    <div class="space-y-3">
      <input ref="fileInput" type="file" accept="image/png,image/jpeg,image/webp" multiple class="hidden" @change="onFileChange" />
      <div class="flex flex-wrap gap-2">
        <Button variant="outline" @click="fileInput.click()"><Upload />选择图片</Button>
        <Button variant="outline" @click="saveText">仅保存文字</Button>
        <Button v-if="!store.aiDown" :disabled="store.busy" @click="runAI"><Sparkles />{{ store.busy ? '分析中…' : 'AI 整理' }}</Button>
        <Button v-if="store.pendingSave" variant="outline" :disabled="store.busy" @click="retrySave"><RefreshCw />重试保存分析结果（不重调模型）</Button>
      </div>
      <Alert v-if="store.aiDown" variant="warning">模型不可用：AI 入口已隐藏；「仅保存」与本地浏览不受影响。</Alert>
      <p v-if="store.pendingSave" class="text-xs text-muted-foreground">上次 AI 分析成功但本地保存失败，结果已暂存（刷新不丢）；重试只重新落库，不会再次请求模型。</p>
      <Textarea v-model="textDraft" placeholder="或粘贴 / 输入纯文字…" class="min-h-24" />
      <div class="flex flex-wrap items-center gap-2">
        <Input v-model="referenceAt" placeholder="参照日期（可选 YYYY-MM-DD）" class="max-w-xs" />
        <span class="text-xs text-muted-foreground">相对时间（明天/下周三）的换算参照；不填则无可靠参照时留空。保存日不作参照。</span>
      </div>
      <div v-if="store.pendingSource" class="rounded-md border p-3 space-y-2">
        <div class="text-sm text-muted-foreground">待处理：{{ store.pendingSource.kind === 'image' ? store.pendingSource.name : '文字资料' }} · {{ store.pendingSource.captured_at }}</div>
        <img v-if="pendingUrl" :src="pendingUrl" alt="待处理截图" class="max-h-64 rounded-md border" />
        <pre v-else class="overflow-auto rounded-md bg-muted p-2 text-xs">{{ store.pendingSource.text }}</pre>
      </div>
    </div>
  </Card>
</template>