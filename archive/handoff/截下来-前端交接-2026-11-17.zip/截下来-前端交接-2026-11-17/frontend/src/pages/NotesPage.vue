<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { PanelRight, RefreshCw } from 'lucide-vue-next'
import Alert from '@/components/ui/Alert.vue'
import Badge from '@/components/ui/Badge.vue'
import Button from '@/components/ui/Button.vue'
import Card from '@/components/ui/Card.vue'
import Input from '@/components/ui/Input.vue'
import Separator from '@/components/ui/Separator.vue'
import FieldCard from '@/components/domain/FieldCard.vue'
import { useAppStore } from '@/stores/app'
import { getSource } from '@/services/storage/db'
import { CONTENT_TYPE_LABELS, STATUS_LABELS, label } from '@/domains/labels'

const store = useAppStore()
const route = useRoute()
const router = useRouter()
const manualDeadline = ref('')
const referenceAt = ref('')
const evidenceSource = ref(null)

const statusVariant = { draft: 'warning', reviewed: 'success', failed: 'destructive' }
const hasConfirmedDeadline = computed(() =>
  !!store.selectedNote && store.selectedNote.fields.some((f) => f.key === 'deadline' && f.status === 'confirmed' && f.value != null),
)

watch(() => route.params.id, (id) => {
  if (id && id !== store.selectedNoteId) store.selectNote(id)
}, { immediate: true })
watch(() => store.selectedNote, async (n) => {
  evidenceSource.value = n ? (await getSource(n.source_id)) || null : null
}, { immediate: true })
onMounted(() => {
  if (!route.params.id && store.selectedNoteId) router.replace('/notes/' + store.selectedNoteId)
})

async function createTask() {
  const result = await store.createTask(store.selectedNote)
  if (result && result.ok) router.push('/today')
}
async function createManual() {
  const result = await store.createTaskManual(store.selectedNote, manualDeadline.value)
  if (result && result.ok) {
    manualDeadline.value = ''
    router.push('/today')
  }
}
async function reanalyze() {
  const result = await store.runAnalysis(store.selectedNote.source_id, referenceAt.value)
  if (result && result.ok) router.replace('/notes/' + result.noteId)
}
</script>

<template>
  <div class="space-y-3">
    <div class="flex items-center gap-2">
      <span class="min-w-0 flex-1 truncate text-sm text-muted-foreground">待核对资料队列 → 逐字段确认 → 带出处建任务</span>
      <span class="hidden items-center gap-1 text-xs text-muted-foreground sm:flex"><span class="size-1.5 rounded-full bg-emerald-500" />已保存到本地</span>
      <Button size="sm" variant="outline" :aria-label="store.evidenceOpen ? '收起原文' : '展开原文'" @click="store.evidenceOpen = !store.evidenceOpen">
        <PanelRight />{{ store.evidenceOpen ? '收起原文' : '展开原文' }}
      </Button>
    </div>

    <div class="grid gap-4 lg:grid-cols-[220px_minmax(0,1fr)]" :class="{ 'xl:grid-cols-[220px_minmax(0,1fr)_320px]': store.evidenceOpen }">
      <Card>
        <template #header><div class="text-base font-semibold">资料队列</div></template>
        <div class="space-y-1">
          <button
            v-for="n in store.notes"
            :key="n.id"
            class="w-full rounded-md px-2 py-1.5 text-left text-sm hover:bg-accent"
            :class="{ 'bg-accent': n.id === store.selectedNoteId }"
            @click="router.push('/notes/' + n.id)"
          >
            <div class="truncate font-medium">{{ n.title }}</div>
            <Badge :variant="statusVariant[n.status]" :title="n.status">{{ label(STATUS_LABELS, n.status) }}</Badge>
          </button>
          <p v-if="!store.notes.length" class="text-sm text-muted-foreground">还没有便签。<RouterLink to="/collect" class="underline">去收集箱</RouterLink>保存一份资料。</p>
        </div>
      </Card>

      <Card v-if="store.selectedNote">
        <template #header>
          <div class="flex flex-wrap items-center gap-2">
            <div class="text-base font-semibold">{{ store.selectedNote.title }}</div>
            <Badge :variant="statusVariant[store.selectedNote.status]" :title="store.selectedNote.status">{{ label(STATUS_LABELS, store.selectedNote.status) }}</Badge>
            <Badge variant="secondary" :title="store.selectedNote.content_type">{{ label(CONTENT_TYPE_LABELS, store.selectedNote.content_type) }}</Badge>
          </div>
        </template>
        <div class="space-y-3">
          <FieldCard v-for="f in store.selectedNote.fields" :key="f.key" :note="store.selectedNote" :field="f" />
          <p v-if="!store.selectedNote.fields.length" class="text-sm text-muted-foreground">分析失败或尚未分析，原图仍保留，可重试。</p>
          <Alert v-if="store.selectedNote.warnings && store.selectedNote.warnings.length" variant="warning">
            <div v-for="w in store.selectedNote.warnings" :key="w.code + (w.field_key || '')" class="text-xs">
              <span class="font-medium">{{ w.code }}</span> · {{ w.message }}
            </div>
          </Alert>
          <Separator />
          <div class="flex flex-wrap items-center gap-2">
            <Button :disabled="!hasConfirmedDeadline" :title="hasConfirmedDeadline ? '' : '先独立确认截止时间'" @click="createTask">创建任务</Button>
            <span v-if="!hasConfirmedDeadline" class="text-xs text-muted-foreground">确认截止后，可带入任务</span>
            <Button v-if="store.selectedNote.status === 'draft'" variant="outline" @click="store.reviewNote(store.selectedNote)">标记已审阅</Button>
            <Button variant="outline" :disabled="store.busy || store.aiDown" @click="reanalyze"><RefreshCw />{{ store.selectedNote.status === 'failed' ? '重试分析' : '重新分析' }}</Button>
            <Button variant="destructive" @click="store.deleteNote(store.selectedNote)">删除便签</Button>
          </div>
          <div class="flex flex-wrap items-center gap-2">
            <Input v-model="manualDeadline" placeholder="手动截止 YYYY-MM-DD 或 ISO datetime" class="max-w-xs" />
            <Button variant="outline" @click="createManual">手动截止建任务</Button>
            <Input v-model="referenceAt" placeholder="重分析参照日期（可选）" class="max-w-40" />
          </div>
        </div>
      </Card>
      <Card v-else>
        <p class="text-sm text-muted-foreground">从左侧队列选择一份资料开始核对。</p>
      </Card>

      <Card v-if="store.evidenceOpen">
        <template #header><div class="text-base font-semibold">原始资料</div></template>
        <div class="space-y-2">
          <img v-if="store.imageUrl" :src="store.imageUrl" alt="原始截图" class="max-h-96 w-full rounded-md border object-contain" />
          <pre v-else-if="evidenceSource && evidenceSource.kind === 'text'" class="overflow-auto rounded-md bg-muted p-2 text-xs">{{ evidenceSource.text }}</pre>
          <p v-else class="text-sm text-muted-foreground">原始资料不可被编辑覆盖。</p>
          <p v-if="evidenceSource" class="text-xs text-muted-foreground">收集于 {{ evidenceSource.captured_at }} · 字段引用与原文同时查看</p>
        </div>
      </Card>
    </div>
  </div>
</template>