import { createRouter, createWebHashHistory } from 'vue-router'
import TodayPage from '@/pages/TodayPage.vue'
import CollectPage from '@/pages/CollectPage.vue'
import NotesPage from '@/pages/NotesPage.vue'

// 托管未验证 history 回退前用 hash 模式，保证深链接刷新可恢复。
export const router = createRouter({
  history: createWebHashHistory(),
  routes: [
    { path: '/', redirect: '/today' },
    { path: '/today', component: TodayPage, meta: { title: '今天' } },
    { path: '/collect', component: CollectPage, meta: { title: '收集箱' } },
    { path: '/notes', component: NotesPage, meta: { title: '便签核对' } },
    { path: '/notes/:id', component: NotesPage, meta: { title: '便签核对' } },
  ],
})